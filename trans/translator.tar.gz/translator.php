<?
$URL="http://". $_SERVER["HTTP_HOST"] . $_SERVER["REQUEST_URI"];
?>
<html>
<body>
<table style="text-align: left; width: 200px;" border="0"
cellpadding="0" cellspacing="0">
<tbody>
<tr>
<td><a
href="http://translate.google.com/translate_c?hl=en&amp;langpair=en%7Cfr&amp;u=<?echo $URL;?>"><img
style="border: 0px solid ; width: 30px; height: 20px;"
alt="Fran&ccedil;ais/French"
src="http://byethost.com/images/frenchflag.jpg"></a></td>
<td><a
href="http://translate.google.com/translate_c?hl=en&amp;langpair=en%7Cde&amp;u=<?echo $URL;?>"><img
style="border: 0px solid ; width: 30px; height: 20px;"
alt="Deutsch/German"
src="http://byethost.com/images/germanflag.jpg"></a></td>
<td><a
href="http://translate.google.com/translate_c?hl=en&amp;langpair=en%7Cit&amp;u=<?echo $URL;?>"><img
style="border: 0px solid ; width: 30px; height: 20px;"
alt="Italiano/Italian"
src="http://byethost.com/images/italianflag.jpg"></a></td>
<td><a
href="http://translate.google.com/translate_c?hl=en&amp;langpair=en%7Cnl&amp;u=<?echo $URL;?>"><img
title="Netherlands/Dutch"
style="border: 0px solid ; width: 30px; height: 20px;"
alt="Netherlands/Dutch"
src="http://byethost.com/images/flag-netherlands.jpg"></a></td>
<td><a
href="http://translate.google.com/translate_c?hl=en&amp;langpair=en%7Ces&amp;u=<?echo $URL;?>"><img
style="border: 0px solid ; width: 30px; height: 20px;"
alt="Espa&ntilde;ol/Spanish"
src="http://byethost.com/images/spanishflag.jpg"></a></td>
<td>
<a href="http://translate.google.com/translate_c?hl=en&amp;langpair=en%7Cpt&amp;u=<?echo $URL;?>"><img
style="border: 0px solid ; width: 30px; height: 20px;"
alt="Portugu&ecirc;s/Portuguese"
src="http://byethost.com/images/portugeseglag.jpg"></a></td>
</tr>
<tr>
<td>
<a href="http://translate.google.com/translate_c?hl=en&langpair=en%7Cko&u=<?echo $URL;?>">
<img style="border: 0px solid ; width: 30px; height: 20px;" alt="한국어/Korean" src="http://byethost.com/images/koreanflag.jpg"></a>
</td>

<td>
<a href="http://translate.google.com/translate_c?hl=en&amp;langpair=en%7Czh-CN&amp;u=<?echo $URL;?>">
<img style="border: 0px solid ; width: 30px; height: 20px;" alt="中文（简体）/Chinese Simplified"
src="http://byethost.com/images/chineseflag.jpg"></a>
</td>

<td>
<a href="http://translate.google.com/translate_c?hl=en&langpair=en%7Cja&u=<?echo $URL;?>">
<img style="border: 0px solid ; width: 30px; height: 20px;" alt="日本語/Japanese"
src="http://byethost.com/images/japanflag.jpg"></a>
</td>

<td>
<a href="http://translate.google.com/translate_c?hl=en&amp;langpair=en%7Cel&amp;u=<?echo $URL;?>"><img
style="border: 0px solid ; width: 30px; height: 20px;"
alt="Greek" src="http://byethost.com/images/greekflag.gif"></a></td>
<td>
<a
href="http://translate.google.com/translate_c?hl=en&amp;langpair=en%7Car&amp;u=<?echo $URL;?>"><img
title="Arabic / UAE"
style="border: 0px solid ; width: 30px; height: 20px;"
alt="Arabic / UAE"
src="http://byethost.com/images/arabic_flag.bmp"></a></td>
<td><a
href="http://translate.google.com/translate_c?hl=en&amp;langpair=en%7Cru&amp;u=<?echo $URL;?>"><img
title="Russia/Russian"
style="border: 0px solid ; width: 30px; height: 20px;"
alt="Russia/Russian" src="http://byethost.com/images/russia.gif"></a></td>
</tr>
</tbody>

