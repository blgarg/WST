<?php
// Version: 2.0; Settings

global $settings;

$txt['theme_thumbnail_href'] = $settings['images_url'] . '/thumbnail.gif';
$txt['theme_description'] = 'The default theme of SMF\'s previous incarnation, codenamed Core.<br /><br />Author: The Simple Machines Team';

?>